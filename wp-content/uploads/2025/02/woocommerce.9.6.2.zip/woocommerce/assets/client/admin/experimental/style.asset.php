<?php return array('version' => 'cd26f7481e9b6db96472');
