<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-hooks'), 'version' => 'abe09e9fbde8c7b104e3');
