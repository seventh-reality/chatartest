<?php return array('version' => 'a786c7067f63d673fbb3');
